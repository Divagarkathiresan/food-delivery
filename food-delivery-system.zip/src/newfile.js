import React from "react";
function (){
	return(
		<div>
			<h1>Hello</h1>
		</div>
	);
}
export default ;